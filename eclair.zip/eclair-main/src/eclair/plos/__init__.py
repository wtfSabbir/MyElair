"""Pole-like objects (PLOs)."""
